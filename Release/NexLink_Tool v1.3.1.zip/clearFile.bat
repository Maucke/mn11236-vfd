rd /s /q ca-ES
rd /s /q cs-CZ
rd /s /q de
rd /s /q en
rd /s /q es
rd /s /q fr
rd /s /q hu
rd /s /q it
rd /s /q ja
rd /s /q ko
rd /s /q nl-BE
rd /s /q pl
rd /s /q pt
rd /s /q ro
rd /s /q ru
rd /s /q sv
rd /s /q zh-Hans
rd /s /q zh-Hant
rd /s /q SysLog
rd /s /q Log
del *.xml
del /s /q *.pdb

